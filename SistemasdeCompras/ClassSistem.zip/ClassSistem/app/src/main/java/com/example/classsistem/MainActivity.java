package com.example.classsistem;

import android.os.Bundle;
import android.app.Activity;
import android.widget.*;
import android.app.AlertDialog;
import android.content.DialogInterface;


public class MainActivity extends Activity {
    TextView txtstatus;
    RatingBar rtbvotacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtstatus = findViewById(R.id.txtstatus);
        rtbvotacao = findViewById(R.id.rtbvotacao);

        txtstatus.setText("Status: Ruim");

        rtbvotacao.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("Tem certeza que deseja avaliar com " + rating + " estrelas?")
                        .setCancelable(false)
                        .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                if (rating == 1)
                                    txtstatus.setText("Status: Regular");
                                else if (rating == 2)
                                    txtstatus.setText("Status: Bom");
                                else if (rating == 3)
                                    txtstatus.setText("Status: Ótimo");
                                else if (rating == 4)
                                    txtstatus.setText("Status: Excelente");
                                else if (rating == 5)
                                    txtstatus.setText("Status: Espetacular");
                            }
                        })
                        .setNegativeButton("Não", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });

    }
}
